<?php


	print "data = [{
		
						\"WIFI_SSID\" : \"yooooooo\",
						\"IPAddress\" : \"192.168.0.4\",
						\"Port\" : \"80\",
						\"Wmode\" : \"Access Point\",
						\"WEB_USER\" : \"webadmin\",
						\"HI\" : \"100\"										
					}]; ";


?>