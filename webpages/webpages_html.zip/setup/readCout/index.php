<?php

if(isset($_GET["c_in"]))
{
	print "hellloooooooooooo\r\n";
	print $_GET["c_in"];
}

?>