<?php

					
					
	print "[	
					{\"SSID\" : \"SSID1\"},
					{\"SSID\" : \"SSID2\"},
					{\"SSID\" : \"SSID3\"},
					{\"SSID\" : \"SSID4\"}
				  ]";	






?>