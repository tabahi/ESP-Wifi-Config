<?php


	print "var msg = \"Hello\"";


?>