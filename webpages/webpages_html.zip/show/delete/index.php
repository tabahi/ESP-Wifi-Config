<?php

	if(isset($_GET["drfid"]))
	{
		print "Successfully Deleted: ";
		print $_GET["drfid"];
	}
	else
	{
		print "ERROR";
	}







?>